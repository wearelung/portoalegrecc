require 'rake'
require 'rubygems'
require 'fileutils'
require "bundler"

set :application, "portoalegrecc"
set :repository, "git@git.com:portoalegrecc.git"
set :scm, :git
set :branch, 'master'

set :path, "/home/ubuntu/www"
set :apache_cmd_path, "/etc/init.d/apache2"  
set :deploy_to, "#{path}/portoalegrecc"

after "deploy", "deploy:cleanup"

server "localhost", :app, :web, :db, :primary => true
ssh_options[:username] = 'ubuntu'
ssh_options[:keys] = "/home/ubuntu/.cruise/poakey.pem"
ssh_options[:paranoid] = false

default_run_options[:pty] = true

set :user, "ubuntu"
set :use_sudo, false

task :staging do
  desc "CI: Deploy to staging"
  
  RAILS_ENV = 'staging'
  sh "bundle install --local --path vendor/bundle"
  Bundler.setup(:default, :staging)
  puts "[Mostrar INFO do RVM]   #{`rvm info`}"
  run("cd #{deploy_to}/current && bundle exec rake db:create")
  run("cd #{deploy_to}/current && bundle exec rake db:migrate")
end

namespace :deploy do
  desc "Custom restart task for webserver"
  task :restart, :roles => :app, :except => { :no_release => true } do
    run "/home/ubuntu/webserver.sh"
  end

  desc "Custom start task for webserver"
  task :start, :roles => :app do
    run "/home/ubuntu/webserver.sh"
  end

  desc "Custom stop task for apache server"
  task :stop, :roles => :app do
    run "cd #{deploy_to}/current && sudo :apache_cmd_path stop || true"
  end

end
